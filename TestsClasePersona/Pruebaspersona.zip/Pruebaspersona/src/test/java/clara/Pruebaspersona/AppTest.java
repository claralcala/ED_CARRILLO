package clara.Pruebaspersona;


import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

public class AppTest {
	//Creamos tres objetos llamados persona, persona2 y persona3 con diferentes caracter�sticas
	App persona = new App("Pepe", 25, 'H', 90, 1.90);
	App persona2 = new App("Maria", 17, 'M', 40, 1.64);
	App persona3 = new App ("Luis", 19, 'T', 120, 1.90);
	
	
	@Test
	/**
	 * En este test comprobaremos con una persona mayor de edad y otra persona menor que
	 * nos devuelve lo esperado true/false
	 */
	public void mayorEdad() {
		assertTrue(persona.esMayorDeEdad());
		assertFalse(persona2.esMayorDeEdad());
	}
	@Test
	/*
	 * En este test comprobaremos que el sexo esperado coincide con el asignado
	 * La tercera persona tiene como sexo 'T', as� que, si funciona, deber�a reasignarse a 'H'
	 * 
	 */
	public void comprobarSexo() {
		persona.comprobarSexo();
		persona2.comprobarSexo();
		persona3.comprobarSexo();
		assertEquals('H', persona.sexo);
		assertEquals('M', persona2.sexo);
		assertEquals(persona3.sexo, 'H');
	}
	
	@Test
	/*
	 * Por �ltimo, cada persona tendr� un peso y una altura distintas y comprobamos que
	 * devuelve los valores que se esperan
	 */
	public void calcularIMC() {
		
		assertEquals(0, persona.calcularIMC());
		assertEquals(-1, persona2.calcularIMC());
		assertEquals(1, persona3.calcularIMC());
		
		
	}
	@Test
	public void generarDNI() {
		//Generamos otra persona con los mismos datos que la persona original
		App persona4 = new App("Pepe", 25, 'H', 90, 1.90);
		//Generamos los dni de persona y persona4
		persona.generarDni();
		persona4.generarDni();
		//Comprobamos que persona y persona4 no sean iguales
		assertNotSame(persona, persona4);
	}

	
	
}
