package clara.pruebaseriesvideojuegos2;

import static org.junit.jupiter.api.Assertions.assertTrue;

import org.hamcrest.core.IsInstanceOf;
import org.hamcrest.core.IsNot;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;



import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;
import java.util.Arrays;
import java.util.List;

public class AppTest    
{
	Videojuego video1= new Videojuego("The Legend of Zelda: Breath of the Wild", 100, "aventura", "Nintendo");
	Videojuego video2= new Videojuego("Red Dead Redemption 2", 100, "aventura", "Rockstar");
	Videojuego video3 = new Videojuego("Persona 4 Golden", 50, "RPG", "Atlus");
	Videojuego video4 =new Videojuego("The Legend of Zelda: Breath of the Wild", 100, "aventura" , "Nintendo");
	Serie serie1= new Serie("Juego de tronos", 9, "fantas�a", "HBO");
	Serie serie2= new Serie("Stranger Things", 4, "ciencia ficci�n", "Netflix");
	Serie serie3= new Serie("The Good Place", 4, "fantas�a, comedia", "Netflix");
	Serie serie4 =new Serie("Twin Peaks", 2, "policiaca" , "David Lynch");
	Serie serie5= new Serie("Twin Peaks", 2, "policiaca", "David Lynch");
	//Primero vamos a hacer tests con la serie
	
	
	
	@Test
	@DisplayName("Comprobamos que se entregue y devuelva true")
	public void testEntregadoTrue() {
		video1.entregar();
		  
		  boolean result = video1.isEntregado();
		  assertThat(result, is(true));
		
	}
	@Test
	@DisplayName("Ahora comprobamos que devuelva false porque no entregamos el videojuego")
	public void testEntregadoFalse() {
		 boolean result = video1.isEntregado();
		  assertThat(result, is(false));
		
	}
	
	@Test
	@DisplayName("Comprobamos que el juego 1 es mayor que el 3")
	public void testMayor() {
		
		  int result = video1.compareTo(video3);
		  assertThat(result, is(Videojuego.MAYOR));
	}
	
	@Test
	@DisplayName("Comprobamos que videojuego 1 y 2 son iguales")
	public void testIgual() {
		int result= video1.compareTo(video2);
		assertThat(result, is(Videojuego.IGUAL));
	}

	@Test
	@DisplayName("Comprobamos que el juego 3 es menor que el 1")
	public void testMenor() {
		int result=video3.compareTo(video1);
		assertThat(result, is (Videojuego.MENOR));
	}
	
	@Test
	@DisplayName("Comprobamos que un array de juegos tiene tama�o de 3")
	public void testArrayJuegos() {
		List<Videojuego> list = Arrays.asList(video1, video2, video3);

        assertThat(list, hasSize(3));
	}
	
	@Test
	@DisplayName("Comprobamos que un array de series tiene tama�o de 4")
	public void testArraySeries() {
		List<Serie> list=Arrays.asList(serie1, serie2, serie3, serie4);
		assertThat(list, hasSize(4));
	}
	
	@Test 
	@DisplayName("Comprobamos que un array de juegos contiene lo que se espera")
	public void testArrayJuegos2() {
		List<Videojuego> list = Arrays.asList(video1, video2, video3);
		assertThat(list, contains(video1, video2, video3));
	}
	
	@Test
	@DisplayName("Lo mismo que el anterior pero con series")
	public void testArraySeries2() {
		List<Serie> list= Arrays.asList(serie1, serie2, serie3);
		assertThat(list, contains (serie1, serie2, serie3));
	}
	
	@Test 
	@DisplayName("Comprobamos que los elementos de un array de juegos tienen el atributo g�nero")
	public void testArrayJuegos3() {
		List<Videojuego> list = Arrays.asList(video1, video2, video3);
		assertThat(list, everyItem(hasProperty("genero")));
	}
	
	@Test
	@DisplayName("Comprobamos que los elementos de un array de series tienen el atributo t�tulo")
	public void testArraySeries3() {
		List<Serie> list = Arrays.asList(serie1, serie2, serie3);
		assertThat(list, everyItem(hasProperty("titulo")));
	}
	
	@Test 
	@DisplayName("Comprobamos que los elementos de un array de juegos tienen el atributo t�tulo")
	public void testArrayJuegos4() {
		List<Videojuego> list = Arrays.asList(video1, video2, video3);
		assertThat(list, everyItem(hasProperty("titulo")));
	}
	
	
	@Test 
	@DisplayName("Comprobamos que los elementos de un array de juegos tienen el atributo horasEstimadas")
	public void testArrayJuegos5() {
		List<Videojuego> list = Arrays.asList(video1, video2, video3);
		assertThat(list, everyItem(hasProperty("horasEstimadas")));
	}
	
	
	@Test 
	@DisplayName("Comprobamos que los elementos de un array de juegos tienen el atributo entregado")
	public void testArrayJuegos6() {
		List<Videojuego> list = Arrays.asList(video1, video2, video3);
		assertThat(list, everyItem(hasProperty("entregado")));
	}
	
	@Test 
	@DisplayName("Comprobamos que los elementos de un array de juegos tienen el atributo compa��a")
	public void testArrayJuegos7() {
		List<Videojuego> list = Arrays.asList(video1, video2, video3);
		assertThat(list, everyItem(hasProperty("compania")));
	}
	
	@Test
	@DisplayName("Comprobamos que los elementos de un array de series tienen el atributo numeroTemporadas")
	public void testArraySeries4() {
		List<Serie> list = Arrays.asList(serie1, serie2, serie3);
		assertThat(list, everyItem(hasProperty("numeroTemporadas")));
	}
	
	
	@Test
	@DisplayName("Comprobamos que los elementos de un array de series tienen el atributo entregado")
	public void testArraySeries5() {
		List<Serie> list = Arrays.asList(serie1, serie2, serie3);
		assertThat(list, everyItem(hasProperty("entregado")));
	}
	
	@Test
	@DisplayName("Comprobamos que los elementos de un array de series tienen el atributo creador")
	public void testArraySeries6() {
		List<Serie> list = Arrays.asList(serie1, serie2, serie3);
		assertThat(list, everyItem(hasProperty("creador")));
	}
	
	@Test 
	@DisplayName("Comprobamos que dos juegos no sean iguales")
	public void equalsFalseJuegos() {
		assertThat(video2, is(not(equalTo(video3))));
	}
	
	
	
	@Test
	@DisplayName("Comprobamos que dos series no sean iguales")
	public void equalsFalseSeries() {
		assertThat(serie1, is(not(equalTo(serie2))));
	}
	
	@Test
	@DisplayName("Comprobamos que una serie se entregue y devuelva true")
	public void testEntregadoTrueSerie() {
		serie1.entregar();
		  
		  boolean result = serie1.isEntregado();
		  assertThat(result, is(true));
		
	}
	@Test
	@DisplayName("Ahora comprobamos que devuelva false porque no entregamos la serie")
	public void testEntregadoFalseSerie() {
		 boolean result = serie1.isEntregado();
		  assertThat(result, is(false));
		
	}
	
	@Test
	@DisplayName("Comprobamos que una serie es mayor que otra")
	public void testMayorSerie() {
		
		  int result = serie1.compareTo(serie3);
		  assertThat(result, is(Serie.MAYOR));
	}
	
	@Test
	@DisplayName("Comprobamos que dos series son iguales")
	public void testIgualSerie() {
		int result= serie2.compareTo(serie3);
		assertThat(result, is(Serie.IGUAL));
	}

	@Test
	@DisplayName("Comprobamos que una serie es menor que otra")
	public void testMenorSerie() {
		int result=serie3.compareTo(serie1);
		assertThat(result, is (Serie.MENOR));
	}
	
	@Test 
	@DisplayName("En estos test consecutivos comprobamos que un objeto pertenece a la clase Videojuego")
	public void comprobarClaseJuego1() {
		assertThat(video1, instanceOf(Videojuego.class));
	}
	
	@Test 
	public void comprobarClaseJuego2() {
		assertThat(video2, instanceOf(Videojuego.class));
	}
	
	@Test 
	public void comprobarClaseJuego3() {
		assertThat(video3, instanceOf(Videojuego.class));
	}
	
	@Test 
	public void comprobarClaseJuego4() {
		assertThat(video4, instanceOf(Videojuego.class));
	}
	
	@Test 
	@DisplayName("En estos test consecutivos comprobamos que unos objetos pertenecen a la clase Serie")
	public void comprobarClaseSerie1() {
		assertThat(serie1, instanceOf(Serie.class));
	}
	
	@Test 
	public void comprobarClaseSerie2() {
		assertThat(serie2, instanceOf(Serie.class));
	}
	
	@Test 
	public void comprobarClaseSerie3() {
		assertThat(serie3, instanceOf(Serie.class));
	}
	
	@Test 
	public void comprobarClaseSerie4() {
		assertThat(serie4, instanceOf(Serie.class));
	}
	
	@Test 
	public void comprobarClaseSerie5() {
		assertThat(serie5, instanceOf(Serie.class));
	}
	
	
	    
}
