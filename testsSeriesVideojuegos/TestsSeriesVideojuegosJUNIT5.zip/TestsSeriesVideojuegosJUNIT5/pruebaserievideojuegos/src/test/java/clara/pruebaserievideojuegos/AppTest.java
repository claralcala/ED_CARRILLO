package clara.pruebaserievideojuegos;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.*;



	
public class AppTest    
{
	Videojuego video1= new Videojuego("The Legend of Zelda: Breath of the Wild", 100, "aventura", "Nintendo");
	Videojuego video2= new Videojuego("Red Dead Redemption 2", 100, "aventura", "Rockstar");
	Videojuego video3 = new Videojuego("Persona 4 Golden", 50, "RPG", "Atlus");
	Serie serie1= new Serie("Juego de tronos", 9, "fantas�a", "HBO");
	Serie serie2= new Serie("Stranger Things", 4, "ciencia ficci�n", "Netflix");
	Serie serie3= new Serie("The Good Place", 4, "fantas�a, comedia", "Netflix");
	//Primero vamos a hacer tests con la serie
	
	    @Test
	    @DisplayName("Entregamos la serie y comprobamos que se haya entregado")
	    public void testEntregar() {
	        serie1.entregar();
	        assertTrue(serie1.isEntregado());
	    }
	    
	   
	    @Test 
	    @DisplayName("Ahora la devolvemos y comprobamos que el isEntregado nos devuelve False")
	    public void testDevolver() {
	        serie1.devolver();
	        assertFalse(serie1.isEntregado());
	    }
	    
	    @Test
	    @DisplayName("Este test compara que la serie 1 tenga m�s temporadas que la 3")
	    public void testCompareToMayor() {
	        assertEquals(Serie.MAYOR, serie1.compareTo(serie3));
	        
	        
	    }
	    
	    @Test
	    @DisplayName("Este test compara que la serie 3 tenga menos temporadas que la 1")
	    public void testCompareToMenor() {
	    	assertEquals(Serie.MENOR, serie3.compareTo(serie1));
	    }
	    
	    
	    @Test
	    @DisplayName("Este test compara que las series 2 y 3 tengan las mismas temporadas")
	    public void testCompareToIgual() {
	    	assertEquals(Serie.IGUAL, serie3.compareTo(serie2));
	    }
	    
	
	    
	    @Test
	    @DisplayName("Este test compara que dos series tengan mismo t�tulo y creador. Debe devolver true")
	    public void testEqualsTrue() {
	    	//Vamos a crear dos nuevos objetos que solo vamos a usar en este test
	    	Serie serie4 =new Serie("Twin Peaks", 2, "policiaca" , "David Lynch");
	    	Serie serie5= new Serie("Twin Peaks", 1, "policiaca", "David Lynch");
	    	assertTrue(serie4.equals(serie5));
	      
	    }
	    @Test
	    @DisplayName("Este test compara que dos series no tengan mismo t�tulo y creador. Debe devolver false")
	    public void testEqualsFalse() {
	    	//Para este test usamos dos de las series que ya ten�amos creadas previamente
	    	assertFalse(serie1.equals(serie2));
	    }
	    
	    
	    //Ahora vamos a hacer test con la clase Videojuego
	    @Test
	    @DisplayName("En este test entregamos el videojuego 1 y comprobamos que entregado devuelva true")
	    public void testEntregarVideo() {
	    	video1.entregar();
	    	assertTrue(video1.isEntregado());
	    }
	    
	    @Test
	    @DisplayName("En este test devolvemos el videojuego 1 y comprobamos que isEntregado nos da False")
	    public void testDevolverVideo() {
	    	video1.devolver();
	    	assertFalse(video1.isEntregado());
	    }
	    
	    @Test
	    @DisplayName("Este test compara que el videojuego1 tenga m�s horas que el videojuego 3")
	    public void testCompareToMayorVideojuego() {
	        assertEquals(Videojuego.MAYOR, video1.compareTo(video3));
	        
	    }  
	    
	    @Test
	    @DisplayName("Este test compara que el videojuego2 tenga m�s horas que el videojuego 3")
	    public void testCompareToMayorVideojuego2() {
	        assertEquals(Videojuego.MAYOR, video2.compareTo(video3));
	        
	    }  
	    @Test
	    @DisplayName("Este test compara que el videojuego3 tenga menos horas que el 2")
	    public void testCompareToMenorrVideojuego() {
	        assertEquals(Videojuego.MENOR, video3.compareTo(video2));
	        
	    } 
	    @Test
	    @DisplayName("Este test compara que el juego 1 y el 2 tengan las mismas horas estimadas")
	    
	    public void testCompareToIgualVideojuego() {
	        assertEquals(Videojuego.IGUAL, video1.compareTo(video2));
	        
	    } 
	    @Test
	    @DisplayName("Este test compara que dos videojuegos sean iguales")
	    public void testEqualsTrueVideojuegos() {
	    	//Creamos un juego con mismo nombre y compa��a que el videojuego 1, pero cambiando g�nero y n� de horas
	    	Videojuego video4 =new Videojuego("The Legend of Zelda: Breath of the Wild", 90, "Mundo abierto" , "Nintendo");
	    	
	    	assertTrue(video4.equals(video1));
	      
	    }
	    
	    @Test
	    @DisplayName("Este test compara que videojuegos no tengan mismo t�tulo y creador. Debe devolver false")
	    public void testEqualsFalseVideojuegos() {
	    	//Para este test usamos dos de los juegos que ya ten�amos creados previamente
	    	assertFalse(video1.equals(video2));
	    }
	    
	    
	}
	    
	
	    
	    
	    
	    
	    

